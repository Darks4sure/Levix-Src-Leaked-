const { MessageEmbed, MessageActionRow, MessageSelectMenu } = require('discord.js');

module.exports = {
    name: 'help',
    aliases: ['h'],
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        let prefix = message.guild?.prefix;

        // Create a MessageSelectMenu
        const selectMenu = new MessageSelectMenu()
            .setCustomId('categorySelect')
            .setPlaceholder('Select a category')
            .addOptions([
                {
                    label: 'AntiNuke',
                    value: 'antinuke',
                    emoji: '<:antinuke:1290920329799008348>',
                },
                {
                    label: 'Moderation',
                    value: 'mod',
                    emoji: '<:mod:1290920326313672766>',
                },
                {
                    label: 'Utility',
                    value: 'info',
                    emoji: '<:Utility:1290957354086563853>',
                },
                {
                    label: 'Welcomer',
                    value: 'welcomer',
                    emoji: '<:wel:1290965902845546506>',
                },
                {
                    label: 'Voice',
                    value: 'voice',
                    emoji: '<:voice:1290957366694772736>',
                },
                {
                    label: 'Automod',
                    value: 'automod',
                    emoji: '<:automod:1290957362542280756>',
                },
                {
                    label: 'Custom Role',
                    value: 'customrole',
                    emoji: '<:role:1290957348705271860>',
                },
                {
                    label: 'Logging',
                    value: 'logging',
                    emoji: '<:logger:1290957359887421463>',
                }
            ]);

        const embed = new MessageEmbed()
            .setColor(client.color)
            .setAuthor({
                name: message.author.tag,
                iconURL: message.author.displayAvatarURL({ dynamic: true })
            })
            .setDescription(
                `**<:prefix:1290958177109676074> Prefix for this server:** \`${prefix}\`\n` +
                `**<:setting:1290958178841923595> Total Commands:** \`${client.commands.size}\`\n` +
                `**<:type:1290958700860932106> Type** \`${prefix}antinuke enable\` **to get started up!**\n\n` +
                `**<:extra:1290957351641284711> __Categories__**\n` +
                `**<:antinuke:1290920329799008348> ‎ : ‎ AntiNuke**\n` +
                `**<:mod:1290920326313672766> ‎ : ‎ Moderation**\n` +
                `**<:automod:1290957362542280756> ‎ : ‎ Automod**\n` +
                `**<:logger:1290957359887421463> ‎ : ‎ Logger**\n` +
                `**<:Utility:1290957354086563853> ‎ : ‎ Utility**\n` +
                `**<:voice:1290957366694772736> ‎ : ‎ Voice**\n` +
                `**<:role:1290957348705271860> ‎ : ‎ Customrole**\n` +
                `**<:wel:1290965902845546506> ‎ : ‎ Welcomer**\n\n` +
                `**<:link:1290957356770791517> __Links__**\n` +
                `[Invite Me](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot) | ` +
                `[Support Server]( https://discord.gg/VgbsEqfX6E)`
            )
            
         /*   .addField(
                '**__Modules__**',
                `
                > <:stolen_emoji:1245605073036378183> \`:\` **[AntiNuke](https://discord.gg/chillparadize)**\n > <:stolen_emoji:1245602859458756649> \`:\` **[Moderation](https://discord.gg/chillparadize)**\n > <:stolen_emoji:1245605497462325298> \`:\` **[Welcomer](https://discord.gg/chillparadize)**\n > <:icons_sound:1252135357999480883> \`:\` **[Voice](https://discord.gg/chillparadize)**\n > <:icon_monitor:1252135575419355188> \`:\` **[Media](https://discord.gg/chillparadize)**\n > <:icon_Extra:1252136320583602269> \`:\` **[Extra](https://discord.gg/chillparadize)**
                `,
                true // This makes the field inline
            )
            .addField(
                    '<:links:1252136775510396973>  **__Links__**',
                    `
                    [Invite](https://discord.com/api/oauth2/authorize?client_id=1246349055861194792&permissions=8&scope=bot) | [Support](https://discord.gg/chillparadize) | [Vote](https://discord.gg/chillparadize)
                    `,
                    false // This makes the field inline
            ); */

        const helpMessage = await message.channel.send({ embeds: [embed], components: [new MessageActionRow().addComponents(selectMenu)] });

        const collector = helpMessage.createMessageComponentCollector({
            filter: (i) => i.user && i.isSelectMenu(),
            time: 60000
        });

        collector.on('collect', async (i) => {
            const category = i.values[0];
            let commands = [];
            if (category === 'all') {
                commands = client.commands
                    .map((x) => `\`${x.name}\``);
                const allCommandsEmbed = new MessageEmbed()
                    .setColor(client.color)
                    .setAuthor({
                        name: client.user.username,
                        iconURL: client.user.displayAvatarURL()
                    })
                    .setDescription(`**All Commands**\n${commands.join(', ')}`);
                helpMessage.edit({ embeds: [allCommandsEmbed], components: [] });
            } else {
                switch (category) {
                    case 'antinuke':
                        commands = client.commands
                            .filter((x) => x.category && x.category === 'security')
                            .map((x) => `\`${x.name}\``);
                        break;
                    case 'mod':
                        commands = client.commands
                            .filter((x) => x.category && x.category === 'mod')
                            .map((x) => `\`${x.name}\``);
                        break;
                    case 'info':
                        commands = client.commands
                            .filter((x) => x.category && x.category === 'info')
                            .map((x) => `\`${x.name}\``);
                        break;
                    case 'welcomer':
                        commands = client.commands
                            .filter((x) => x.category && x.category === 'welcomer')
                            .map((x) => `\`${x.name}\``);
                        break;
                    case 'voice':
                        commands = client.commands
                            .filter((x) => x.category && x.category === 'voice')
                            .map((x) => `\`${x.name}\``);
                        break;
                    case 'automod':
                        commands = client.commands
                            .filter((x) => x.category && x.category === 'automod')
                            .map((x) => `\`${x.name}\``);
                        break;   
                    case 'customrole':
                        commands = client.commands
                            .filter((x) => x.category && x.category === 'customrole')
                            .map((x) => `\`${x.name}\``);
                        break;
                    case 'logging':
                        commands = client.commands
                            .filter((x) => x.category && x.category === 'logging')
                            .map((x) => `\`${x.name}\``);
                        break;                 
                }
                const categoryEmbed = new MessageEmbed()
                    .setColor(client.color)
                    .setAuthor({
                        name: client.user.username,
                        iconURL: client.user.displayAvatarURL()
                    })
                    .setThumbnail(i.guild.iconURL({ dynamic: true }))
                    .setDescription(`**${category.charAt(0).toUpperCase() + category.slice(1)} Commands**\n${commands.join(', ')}`);
                i.reply({ embeds: [categoryEmbed], ephemeral: true });
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                helpMessage.edit({ components: [] });
            }
        });
    }
};
