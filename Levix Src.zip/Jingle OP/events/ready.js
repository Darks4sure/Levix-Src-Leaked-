module.exports = async (client) => {
    client.on('ready', async () => {
        client.user.setPresence({
            activities: [
                {
                    name: `Jingle is Love <3`,
                    type: `PLAYING`
                }
            ],
            status: `idle`
        })
        client.logger.log(`Logged in to ${client.user.tag}`, 'ready')
    })

}
